from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
import threading
import json
from resources.lib.sync_trakt_with_db import sync_trakt_list_metadata
from urllib.parse import urlparse, parse_qs, unquote
import sqlite3
import xbmc
from resources.lib.log_utils import log, LOGERROR, LOGINFO, LOGWARNING
from resources.lib.lists_handler import get_my_lists, get_generic_lists, get_add_options, get_remove_options
import asyncio
from resources.lib.list_handler import handle_list_request
from resources.lib.reload_handler import clear_databases
import sqlite3
from resources.lib.queue_worker import UpdateQueueWorker
from resources.lib.db_sync_manager import sync_lists_and_items
from resources.lib.episodes_handler import get_next_episodes
from resources.lib.watched import update_next_episode, mark_movie_watched, mark_tvshow_watched
from .movies_handler import handle_movie_request
from .discover_handler import handle_discover_request
from .shows_handler import handle_show_request
from resources.lib.indexing import get_genres
from resources.scrapers.scraper_manager import ScraperManager
from .search_handler import search_tmdb
from .list_handler import add_to_list, remove_from_list
from .config_handler import update_config_values, get_trakt_user
from .indexing import add_external_index, del_external_index
from .internal_indexing import add_internal_index, del_internal_index, get_internal_indexes, get_internal_index_contents, get_available_languages
from .lists_handler import get_all_lists, update_list_library_status, delete_list_locally
from .scrape_handler import handle_scrape_request
from .tags_handler import get_all_tags, get_tags_for_item, add_tag_to_item, remove_tag_from_item, get_items_with_tag



class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    trakt_handler = None  # Placeholder for TraktAuth instance
    movies_static_db_path = "movies_static_cache.db"
    movies_dynamic_db_path = "movies_dynamic_cache.db"
    lists_db_path = "lists_cache.db"
    trakt_update_queue_path = "trakt_update_queue.db"
    config_db_conn = None
    trakt_update_queue_path = "trakt_update_queue.db"
    config_db_conn = None
    tags_db_path = "tags_cache.db"
    global_loop = None # Will be set by start_http_server
    trakt_queue_worker = None

    async def _get_trakt_user(self):
        """Fetches the Trakt username."""
        # 1. Try from TraktHandler (memory cache)
        if self.trakt_handler and self.trakt_handler.username:
             return self.trakt_handler.username

        # 2. Try from config DB (Fast, local)
        user = get_trakt_user(config_db_path=self.config_db_path)
        if user:
            # Update memory cache
            if self.trakt_handler:
                self.trakt_handler.username = user
            return user

        # 3. Try fetching from Trakt API via handler (and cache it)
        # Only if we don't have it locally
        if self.trakt_handler:
            user = await self.trakt_handler.fetch_username()
            if user:
                 return user
        
        log("Trakt user not found in config DB or via TraktHandler.", LOGWARNING)
        return None

    async def _handle_scrape_request_async(self, query):
        """Async internal handler for scrape request."""
        results_limit = 0
        if 'results_limit' in query:
             try:
                 results_limit = int(query['results_limit'][0])
             except ValueError:
                 results_limit = 0

        status, body, content_type = await handle_scrape_request(
            query, 
            self.scraper_manager, 
            self.movies_static_db_path, 
            self.tvshows_static_db_path,
            tmdb_handler=self.tmdb_handler,
            results_limit=results_limit,
            global_loop=self.global_loop
        )
        self._send_response(status, body, content_type)

    def _handle_scrape_request(self, query, results_limit=None):
        """Handle scraper requests by running scrapers in the global loop."""
        # results_limit parameter here is for backward compatibility or direct calls
        if results_limit is not None:
             query['results_limit'] = [str(results_limit)]
             
        # Run on the global loop and wait
        future = asyncio.run_coroutine_threadsafe(self._handle_scrape_request_async(query), self.global_loop)
        try:
            future.result() # This just waits for the response to be sent by the async handler
        except (ConnectionAbortedError, BrokenPipeError):
            log("Client disconnected before scrape response could be sent.", LOGWARNING)
        except Exception as e:
            log(f"Error in handle_scrape_request: {e}", LOGERROR)
            try:
                self._send_response(500, {"success": False, "error": str(e)})
            except:
                pass

    def _send_response(self, status, body, content_type="application/json"):
        """Helper to send a standard response."""
        try:
            self.send_response(status)
            self.send_header("Content-type", content_type)
            self.end_headers()
            if isinstance(body, str):
                self.wfile.write(body.encode("utf-8"))
            elif isinstance(body, bytes):
                self.wfile.write(body)
            elif body is not None:
                self.wfile.write(json.dumps(body).encode("utf-8"))
        except (ConnectionAbortedError, BrokenPipeError):
            log(f"Failed to send response: Client disconnected socket ({status})", LOGDEBUG)
        except Exception as e:
            log(f"Failed to send response: {e}", LOGERROR)

    def _flatten_query_params(self, query):
        """Converts a query dict from parse_qs to a flat dict (extracts first value from lists)."""
        flat_params = {}
        for k, v in query.items():
            if v and len(v) > 0:
                flat_params[k] = v[0]
            else:
                flat_params[k] = None
        return flat_params


    def do_GET(self):
        # Run the async GET handler on the global loop
        future = asyncio.run_coroutine_threadsafe(self._do_GET_async(), self.global_loop)
        try:
            future.result()
        except Exception as e:
            log(f"Error in do_GET: {e}", LOGERROR)
            self._send_response(500, b"Internal Server Error", "text/plain")

    async def _do_GET_async(self):
        log(f"Received GET request for path: {self.path}", LOGINFO)
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        raw_query_string = parsed_path.query
        log(f"Parsed query string: '{unquote(raw_query_string)}'", LOGINFO)
        query = parse_qs(raw_query_string)
        log(f"Parsed query dict: {query}", LOGINFO)
        
        # Detailed request logging for debugging
        log(f"[REQUEST DEBUG] Type: GET", LOGINFO)
        log(f"[REQUEST DEBUG] Path: {path}", LOGINFO)
        log(f"[REQUEST DEBUG] Parameters: {query}", LOGINFO)
        log(f"[REQUEST DEBUG] Body: None (GET request)", LOGINFO)

        # Route mapping
        routes = {
            "/ping": self._handle_ping,
            "/movie": self._handle_movie_request,
            "/show": self._handle_show_request,
            "/list": self._handle_list_request,
            "/lists": self._handle_lists_request,
            "/next_episodes": self._handle_next_episodes,
            "/search_tmdb": self._handle_search_tmdb,
            "/get_genres": self._handle_get_genres,
            "/scrape": self._handle_scrape_request_async, # Use async directly to avoid deadlock
            "/fast_start_episode": self._handle_fast_start_episode,
            "/get_external_indexes": self._handle_get_external_indexes,
            "/get_internal_indexes": self._handle_get_internal_indexes,
            "/internal_index_contents": self._handle_internal_index_contents,
            "/internal_index_contents": self._handle_internal_index_contents,
            "/internal_index_contents": self._handle_internal_index_contents,
            "/get_available_languages": self._handle_get_available_languages,
            "/tmdb_keywords": self._handle_tmdb_keywords_request,
            "/force_sync": self._handle_force_sync,
            "/tags": self._handle_get_all_tags,
        }

        # Dynamic routes
        path_parts = path.split('/')
        if path.startswith("/discover/"):
            handler = lambda q: self._handle_discover_request(path, q)
        elif path.startswith("/tags/") and len(path_parts) >= 4:
            if path_parts[3] == 'items':
                # Handle /tags/{tag_name}/items
                handler = lambda q: self._handle_get_tag_items(path_parts[2], q)
            else:
                # Handle /tags/{media_type}/{tmdb_id}
                handler = lambda q: self._handle_get_tags_for_item(path_parts, q)
        else:
            handler = routes.get(path)

        if handler:
            if asyncio.iscoroutinefunction(handler):
                await handler(query)
            else:
                handler(query)
        else:
            self._send_response(404, b"Unknown request", "text/plain")

    def _handle_ping(self, query):
        self._send_response(200, b"Yes, what do you want?", "text/plain")

    def _handle_get_all_tags(self, query):
        """Handle GET /tags - supports ?details=true for counts"""
        try:
            from .tags_handler import get_all_tags, get_all_tags_with_counts
            
            details = query.get("details", ['false'])[0] == 'true'
            
            if details:
                tags = get_all_tags_with_counts(self.tags_db_path)
            else:
                tags = get_all_tags(self.tags_db_path)
            
            self._send_response(200, {"success": True, "tags": tags})
        except Exception as e:
            log(f"[Orac] Error getting all tags: {e}", level=LOGERROR)
            self._send_response(500, {"success": False, "error": "Error getting tags"})

    def _handle_get_tags_for_item(self, path_parts, query):
        """Handle GET /tags/{media_type}/{tmdb_id} - returns tags for a specific item"""
        if len(path_parts) < 4:
            self._send_response(400, {"success": False, "error": "Invalid path. Use /tags/{media_type}/{tmdb_id}"})
            return
        
        media_type = path_parts[2]
        try:
            tmdb_id = int(path_parts[3])
        except ValueError:
            self._send_response(400, {"success": False, "error": "Invalid tmdb_id"})
            return
        
        log(f"[Orac] Getting tags for {media_type}/{tmdb_id}", level=LOGINFO)
        try:
            from .tags_handler import get_tags_for_item
            tags = get_tags_for_item(self.tags_db_path, media_type, tmdb_id)
            self._send_response(200, {"success": True, "tags": tags})
        except Exception as e:
            log(f"[Orac] Error getting tags for item: {e}", level=LOGERROR)
            self._send_response(500, {"success": False, "error": "Error getting tags for item"})

    def _handle_get_tag_items(self, tag_name, query):
        """Handle GET /tags/{tag_name}/items"""
        try:
            from .tags_handler import get_items_with_tag
            
            log(f"[Orac] Getting items for tag: {tag_name}", level=LOGINFO)
            # Fetch basic item info from tags DB
            items = get_items_with_tag(self.tags_db_path, tag_name)
            
            # Enrich items with metadata using static DBs
            enriched_items = []
            for item in items:
                media_type = item['media_type']
                tmdb_id = item['tmdb_id']
                
                try:
                    if media_type == 'movie':
                        # Fetch movie details
                        status, body, _ = handle_movie_request(tmdb_id, self.movies_dynamic_db_path, self.movies_static_db_path, self.tmdb_handler)
                        if status == 200:
                            data = json.loads(body)
                            data['media_type'] = media_type
                            # Add tag-specific sort info if needed, or just use as is
                            enriched_items.append(data)
                            
                    elif media_type in ('show', 'tvshow'):
                        # Fetch show details
                        # handle_show_request usually requires user for watched status, pass empty if needed
                        status, body, _ = handle_show_request(tmdb_id, "", self.tvshows_static_db_path, self.tvshows_dynamic_db_path, self.tmdb_handler)
                        if status == 200:
                            data = json.loads(body)
                            data['media_type'] = media_type
                            enriched_items.append(data)
                            
                except Exception as e:
                    log(f"[Orac] Error enriching item {media_type}/{tmdb_id}: {e}", level=LOGWARNING)
                    # Include basic item if enrichment fails? Or skip?
                    # Let's include a basic placeholder if we can't fetch details?
                    # For now, skip failed enrichments to avoid broken UI
                    continue
            
            self._send_response(200, {"success": True, "items": enriched_items})
            
        except Exception as e:
            log(f"[Orac] Error getting items for tag {tag_name}: {e}", level=LOGERROR)
            import traceback
            log(f"[Orac] Traceback: {traceback.format_exc()}", level=LOGERROR)
            self._send_response(500, {"success": False, "error": f"Error getting items for tag: {e}"})

    def _handle_discover_request(self, path, query):
        parts = path.strip('/').split('/')
        if len(parts) < 2:
            self._send_response(400, b"Invalid discover path. Use /discover/<item_type>", "text/plain")
            return
        item_type = parts[1]
        
        conn = None
        try:
            # Set timeout to handle potential locks from concurrent writes
            # Use DatabaseManager to get connection
            conn = self.db_manager.get_connection(self.external_indexes_db_path)
            cursor = conn.cursor()
            status, body, content_type = handle_discover_request(item_type, query, self.tmdb_handler, cursor)
            self._send_response(status, body, content_type)
        except sqlite3.Error as e:
            log(f"Database error in discover request: {e}", LOGERROR)
            self._send_response(500, b"Database error", "text/plain")
        finally:
            if conn:
                conn.close()

    def _handle_movie_request(self, query):
        movie_tmdb_id = query.get("tmdb_id", [None])[0]
        if not movie_tmdb_id:
            self._send_response(400, b"Missing movie id", "text/plain")
            return
        status, body, content_type = handle_movie_request(movie_tmdb_id, self.movies_dynamic_db_path, self.movies_static_db_path, self.tmdb_handler)
        self._send_response(status, body, content_type)

    async def _handle_show_request(self, query):
        show_tmdb_id = query.get("tmdb_id", [None])[0]
        user = query.get("user", [None])[0] or await self._get_trakt_user() or ""
        if not show_tmdb_id:
            self._send_response(400, b"Missing show tmdb_id", "text/plain")
            return
        status, body, content_type = handle_show_request(show_tmdb_id, user, self.tvshows_static_db_path, self.tvshows_dynamic_db_path, self.tmdb_handler)
        self._send_response(status, body, content_type)

    async def _handle_list_request(self, query):
        list_name = query.get("name", [None])[0]
        item_type = query.get("item_type", [None])[0]
        user = query.get("user", [None])[0] or await self._get_trakt_user()
        log(f"[Orac] Handling /list request for {list_name} of type {item_type} for user {user}", level=LOGINFO)
        status, body, content_type = await handle_list_request(
            list_name, item_type, user, 
            self.movies_dynamic_db_path, self.movies_static_db_path, 
            self.tvshows_dynamic_db_path, self.tvshows_static_db_path, 
            self.list_cache_path,
            trakt_handler=self.trakt_handler,
            tmdb_handler=self.tmdb_handler,
            ext_indexes_db_path=self.external_indexes_db_path
        )
        self._send_response(status, body, content_type)

    async def _handle_lists_request(self, query):
        list_name = query.get("name", ['my_lists'])[0]
        item_type = query.get("item_type", ['All'])[0]
        tmdb_id = query.get("tmdb_id", [None])[0]
        exclude_empty = query.get("exclude_empty", ['false'])[0] == 'true'
        log("[Orac] Handling lists request...", level=LOGINFO)
        
        result = []
        if list_name == 'my_lists':
            if item_type.lower() == 'all':
                result = get_all_lists(self.lists_db_path, self.external_indexes_db_path, exclude_empty=exclude_empty)
            else:
                result = get_my_lists(self.lists_db_path, list_name, item_type, self.external_indexes_db_path, exclude_empty=exclude_empty)
        elif list_name == 'add_list_options':
            trakt_user = await self._get_trakt_user()
            result = get_add_options(self.lists_db_path, item_type, tmdb_id, self.movies_static_db_path, self.tvshows_static_db_path, trakt_user, self.tmdb_handler)
        elif list_name == 'remove_list_options':
            trakt_user = await self._get_trakt_user()
            result = get_remove_options(self.lists_db_path, item_type, tmdb_id, self.movies_static_db_path, self.tvshows_static_db_path, trakt_user, self.tmdb_handler)
        elif list_name == 'generic_lists':
            result = get_generic_lists(self.lists_db_path, list_name, item_type)
        
        if result is not None:
            self._send_response(200, result)
        else:
            self._send_response(500, b"Error getting lists", "text/plain")

    async def _handle_next_episodes(self, query):
        log("[Orac] Handling next episodes request...", level=LOGINFO)
        trakt_user = query.get("user", [None])[0]
        if not trakt_user:
            trakt_user = await self._get_trakt_user()
        
        result = get_next_episodes(self.tvshows_dynamic_db_path, self.tvshows_static_db_path, trakt_user)
        if result is not None:
            self._send_response(200, result)
        else:
            log("[Orac] Error getting next episodes", level=LOGERROR)
            self._send_response(500, b"Error getting next episodes", "text/plain")

    def _handle_search_tmdb(self, query):
        query_str = query.get("name", [None])[0]
        item_type = query.get("item_type", ['multi'])[0]
        if not query_str:
            self._send_response(400, b"Missing search query", "text/plain")
            return
        try:
            results = search_tmdb(query_str, self.tmdb_handler, item_type=item_type)
            self._send_response(200, results)
        except Exception as e:
            log(f"[Orac] Error searching TMDb: {e}", level=LOGERROR)
            self._send_response(500, b"Error searching TMDb", "text/plain")

    def _handle_tmdb_keywords_request(self, query):
        log("[Orac] Handling tmdb_keywords request...", level=LOGINFO)
        keyword = query.get("keyword", [None])[0]
        item_type = query.get("item_type", [None])[0]
        if not keyword or not item_type:
            self._send_response(400, b"Missing keyword or item_type", "text/plain")
            return
        try:
            keywords = self.tmdb_handler.get_keywords(keyword, item_type)
            self._send_response(200, {"success": True, "keywords": keywords})
        except Exception as e:
            log(f"[Orac] Error fetching TMDb keywords: {e}", level=LOGERROR)
            self._send_response(500, b"Error fetching TMDb keywords", "text/plain")

    async def _handle_force_sync(self, query):
        log("[Orac] Received force sync request.", level=LOGINFO)
        # Start sync in background
        asyncio.create_task(self._run_force_sync())
        self._send_response(200, {"status": "started", "message": "Force sync started"})

    async def _run_force_sync(self):
        try:
            log("[Orac] Force sync started via API...", level=LOGINFO)
            username = await self._get_trakt_user()
            await sync_lists_and_items(
                self.trakt_handler,
                self.tmdb_handler,
                self.movies_static_db_path,
                self.movies_dynamic_db_path,
                self.tvshows_static_db_path,
                self.tvshows_dynamic_db_path,
                self.lists_db_path,
                self.trakt_update_queue_path,
                self.trakt_queue_worker,
                username=username,
                external_indexes_db_path=self.external_indexes_db_path,
                config_db_path=self.config_db_path,
                tags_db_path=self.tags_db_path
            )
            log("[Orac] Force sync API request completed successfully.", level=LOGINFO)
        except Exception as e:
            log(f"[Orac] Force sync API request failed: {e}", level=LOGERROR)

    def _handle_get_genres(self, query):
        log("[Orac] Handling get_genres request...", level=LOGINFO)
        item_type = query.get("item_type", [None])[0]
        if not item_type:
            self._send_response(400, b"Missing item_type", "text/plain")
            return
        result = get_genres(self.movies_static_db_path, self.movies_dynamic_db_path, self.tvshows_static_db_path, self.tvshows_static_db_path, item_type)
        if result is not None:
            self._send_response(200, result)
        else:
            self._send_response(500, b"Error getting genres", "text/plain")

    async def _handle_fast_start_episode(self, query):
        log("[Orac] Handling fast_start_episode request...", level=LOGINFO)
        # Call the async scrape handler directly to avoid deadlock in run_coroutine_threadsafe
        query['results_limit'] = ['4']
        await self._handle_scrape_request_async(query)

    def _handle_get_external_indexes(self, query):
        log("[Orac] Handling get_external_indexes request...", level=LOGINFO)
        media_type = query.get("item_type", [None])[0]
        try:
            # Set timeout to handle potential locks from concurrent writes
            with self.db_manager.connection(self.external_indexes_db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM external_indexes where media_type = ?", (media_type,))
                rows = cursor.fetchall()
                indexes = []
                for row in rows:
                    index_item = dict(row)
                    # The 'parameters' field is stored as a JSON string, so we parse it back into an object
                    if 'parameters' in index_item and isinstance(index_item['parameters'], str):
                        index_item['parameters'] = json.loads(index_item['parameters'])
                    indexes.append(index_item)
                self._send_response(200, {"success": True, "indexes": indexes})
        except Exception as e:
            log(f"[Orac] Error fetching external indexes: {e}", level=LOGERROR)
            self._send_response(500, {"success": False, "error": "Error fetching external indexes"})

    def _handle_get_internal_indexes(self, query):
        log("[Orac] Handling get_internal_indexes request...", level=LOGINFO)
        media_type = query.get("item_type", [None])[0]
        if not media_type:
            self._send_response(400, {"success": False, "error": "Missing item_type"})
            return
        try:
            indexes = get_internal_indexes(self.external_indexes_db_path, media_type)
            self._send_response(200, {"success": True, "indexes": indexes})
        except Exception as e:
            log(f"[Orac] Error fetching internal indexes: {e}", level=LOGERROR)
            self._send_response(500, {"success": False, "error": "Error fetching internal indexes"})

    def _handle_get_available_languages(self, query):
        log("[Orac] Handling get_available_languages request...", level=LOGINFO)
        try:
            # We use movies_static_db_path as it contains the 'language' column which we use as the source of truth
            languages = get_available_languages(self.movies_static_db_path)
            self._send_response(200, {"success": True, "languages": languages})
        except Exception as e:
            log(f"[Orac] Error fetching languages: {e}", level=LOGERROR)
            self._send_response(500, {"success": False, "error": "Error fetching languages"})

    async def _handle_internal_index_contents(self, query):
        log("[Orac] Handling internal_index_contents request...", level=LOGINFO)
        index_id = query.get("index_id", [None])[0]
        media_type = query.get("item_type", [None])[0]
        if not index_id or not media_type:
            self._send_response(400, {"success": False, "error": "Missing index_id or item_type"})
            return
        try:
            if media_type == 'movie':
                static_db = self.movies_static_db_path
                dynamic_db = self.movies_dynamic_db_path
            elif media_type == 'tvshow':
                static_db = self.tvshows_static_db_path
                dynamic_db = self.tvshows_dynamic_db_path
            else:
                self._send_response(400, {"success": False, "error": f"Unsupported media_type: {media_type}"})
                return

            user = query.get("user", [None])[0] or await self._get_trakt_user() or ""
            results = get_internal_index_contents(
                self.external_indexes_db_path, index_id, media_type, static_db, dynamic_db, user=user,
                tags_db_path=self.tags_db_path
            )
            self._send_response(200, {"success": True, "results": results})
        except Exception as e:
            log(f"[Orac] Error fetching internal index contents: {e}", level=LOGERROR)
            self._send_response(500, {"success": False, "error": "Error fetching internal index contents"})



    def do_PUT(self):
        # Run the async PUT handler on the global loop
        future = asyncio.run_coroutine_threadsafe(self._do_PUT_async(), self.global_loop)
        try:
            future.result()
        except Exception as e:
            log(f"Error in do_PUT: {e}", LOGERROR)
            self._send_response(500, {"success": False, "error": str(e)})

    async def _do_PUT_async(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        query = parse_qs(parsed_path.query)
        log(f"[Orac] Received PUT request for path: {path}", level=LOGINFO)
        log(f"[Orac] Query parameters: {query}", level=LOGINFO)
        
        # Read body once and store it for debugging and handler use
        self._cached_body_data = None
        self._cached_json_body = None
        content_length = int(self.headers.get('Content-Length', 0))
        
        if content_length > 0:
            self._cached_body_data = self.rfile.read(content_length)
            try:
                self._cached_json_body = json.loads(self._cached_body_data.decode('utf-8'))
                log(f"[REQUEST DEBUG] Type: PUT | Path: {path} | Parameters: {query} | JSON Body: {self._cached_json_body}", LOGINFO)
            except Exception as e:
                log(f"[REQUEST DEBUG] Type: PUT | Path: {path} | Parameters: {query} | Raw Body: {self._cached_body_data.decode('utf-8', errors='replace')}", LOGINFO)
        else:
            log(f"[REQUEST DEBUG] Type: PUT | Path: {path} | Parameters: {query} | Body: None", LOGINFO)

        if path == "/watched":
            log("[Orac] Handling /watched PUT request", level=LOGINFO)
            watched_type = query.get("type", [None])[0]
            if watched_type == "episode":
                season_str = query.get("season", [None])[0]
                episode_str = query.get("episode", [None])[0]
                watched_tmdb_id_str = query.get("tmdb_id", [None])[0]

                if not season_str or not episode_str or not watched_tmdb_id_str:
                    self.send_response(400)
                    self.send_header("Content-type", "text/plain")
                    self.end_headers()
                    self.wfile.write(b"Missing tmdb_id, season or episode number")
                    return

                try:
                    season = int(season_str)
                    episode = int(episode_str)
                    watched_tmdb_id = int(watched_tmdb_id_str)
                    watched_show_trakt_id = int(query.get("show_trakt_id", [0])[0])
                    percent_watched_str = query.get("percent_watched", [None])[0]
                    percent_watched = int(float(percent_watched_str)) if percent_watched_str else 100
                except (ValueError, TypeError):
                    self.send_response(400)
                    self.send_header("Content-type", "text/plain")
                    self.end_headers()
                    self.wfile.write(b"Invalid parameter format")
                    return
                
                log_message = f"Marking episode S{season:02d}E{episode:02d} for show with TMDB ID {watched_tmdb_id} "
                log_message += f"as {percent_watched}% watched" if percent_watched_str else "as watched"
                log(log_message, level=LOGINFO)
                
                username = await self._get_trakt_user()
                update_next_episode(
                    self.tvshows_static_db_path,
                    self.tvshows_dynamic_db_path,
                    self.trakt_update_queue_path,
                    self.trakt_handler,
                    self.tmdb_handler,
                    watched_type,
                    watched_tmdb_id, # This is the show's TMDB ID
                    watched_show_trakt_id,
                    season,
                    episode,
                    percent_watched=percent_watched,
                    username=username
                )

                self.send_response(204)
                self.end_headers()
                return

            elif watched_type == "movie":
                movie_tmdb_id_str = query.get("tmdb_id", [None])[0]
                if not movie_tmdb_id_str:
                    self.send_response(400)
                    self.send_header("Content-type", "text/plain")
                    self.end_headers()
                    self.wfile.write(b"Missing tmdb_id for movie")
                    return
                try:
                    movie_tmdb_id = int(movie_tmdb_id_str)
                    percent_watched_str = query.get("percent_watched", [None])[0]
                    percent_watched = int(float(percent_watched_str)) if percent_watched_str else 100
                except (ValueError, TypeError):
                    self.send_response(400)
                    self.send_header("Content-type", "text/plain")
                    self.end_headers()
                    self.wfile.write(b"Invalid parameter format")
                    return
                
                username = await self._get_trakt_user()
                mark_movie_watched(self.movies_static_db_path, self.movies_dynamic_db_path, self.trakt_update_queue_path, self.trakt_handler, self.tmdb_handler,
                                    movie_tmdb_id, percent_watched=percent_watched,
                                    username=username)
                log(f"[Orac] Marking movie with TMDB ID {movie_tmdb_id} as watched", level=LOGINFO)

                self.send_response(204)
                self.end_headers()
                return

            elif watched_type == "tvshow":
                watched_tmdb_id_str = query.get("tmdb_id", [None])[0]
                if not watched_tmdb_id_str:
                    self.send_response(400)
                    self.send_header("Content-type", "text/plain")
                    self.end_headers()
                    self.wfile.write(b"Missing tmdb_id for tvshow")
                    return
                try:
                    watched_tmdb_id = int(watched_tmdb_id_str)
                    percent_watched_str = query.get("percent_watched", [None])[0]
                    percent_watched = int(float(percent_watched_str)) if percent_watched_str else 100
                except (ValueError, TypeError):
                    self.send_response(400)
                    self.send_header("Content-type", "text/plain")
                    self.end_headers()
                    self.wfile.write(b"Invalid parameter format")
                    return

                username = await self._get_trakt_user()
                mark_tvshow_watched(self.tvshows_static_db_path, self.tvshows_dynamic_db_path, self.trakt_update_queue_path, self.trakt_handler, self.tmdb_handler,
                                    watched_tmdb_id, percent_watched=percent_watched,
                                    username=username)
                log(f"[Orac] Marking tvshow with TMDB ID {watched_tmdb_id} as watched", level=LOGINFO)

                self.send_response(204)
                self.end_headers()
                return

        if path == "/add_to_list":
            log("[Orac] Handling /add_to_list PUT request", level=LOGINFO)
            result = add_to_list(query, self.trakt_handler, self.tmdb_handler, self.lists_db_path, self.movies_static_db_path, self.tvshows_static_db_path, self.trakt_update_queue_path)
            if result.get("status") == "success":
                self.send_response(200)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode('utf-8'))
            else:
                self.send_response(400)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode('utf-8'))
            return

        if path == "/remove_from_list":
            log("[Orac] Handling /remove_from_list PUT request", level=LOGINFO)
            result = remove_from_list(query, self.trakt_handler, self.tmdb_handler, self.lists_db_path, self.movies_static_db_path, self.tvshows_static_db_path, self.trakt_update_queue_path)
            if result.get("status") == "success":
                self.send_response(200)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode('utf-8'))
            else:
                self.send_response(400)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode('utf-8'))
            return

        if path == "/update_trakt_tokens":
            log("[Orac] Handling /update_trakt_tokens PUT request", level=LOGINFO)
            try:
                params = self._flatten_query_params(query)
                result = update_config_values(params, self.config_db_path)
                
                # Reload credentials in handler
                if self.trakt_handler:
                    self.trakt_handler.reload_credentials()
                    # Also try to fetch username immediately to populate cache
                    await self.trakt_handler.fetch_username()
                
                # Re-sync lists in background (optional, or rely on existing logic)
                # Existing logic just returned 200, assuming background process or next request picks it up.
                # But we might want to trigger something here? For now, just confirming creds are reloaded.

                self.send_response(200)
                self.send_header("Content-type", "text/plain")
                self.end_headers()
                self.wfile.write(b"Trakt tokens updated and trakt list metadata sync initiated.")
            except Exception as e:
                log(f"[Orac] Error initiating trakt list metadata sync: {e}", level=LOGERROR)
                self.send_response(500)
                self.send_header("Content-type", "text/plain")
                self.end_headers()
                self.wfile.write(b"Error initiating trakt list metadata sync.")
            return
            
        if path == "/update_tmdb_tokens":
            log("[Orac] Handling /update_tmdb_tokens PUT request", level=LOGINFO)
            try:
                params = self._flatten_query_params(query)
                success = update_config_values(params, self.config_db_path)
                if success:
                    self.send_response(204)
                    self.send_header("Content-type", "text/plain")
                    self.end_headers()
                else:
                    self.send_response(500)
                    self.send_header("Content-type", "text/plain")
                    self.end_headers()
                    self.wfile.write(b"Failed to update TMDB tokens.")
            except Exception as e:
                log(f"[Orac] Unhandled error processing /update_tmdb_tokens: {e}", level=LOGERROR)
                self.send_response(500)
                self.send_header("Content-type", "text/plain")
                self.end_headers()
                self.wfile.write(b"Internal server error.")
            return

        if path == "/add_ext_index":
            log("[Orac] Handling /add_ext_index PUT request", level=LOGINFO)
            try:
                # Use cached body data instead of reading again
                if not self._cached_body_data:
                    self._send_response(400, {"status": "error", "message": "Empty request body"})
                    return

                json_body = self._cached_json_body
                if not json_body:
                    # Try to parse if it wasn't parsed during initial read
                    json_body = json.loads(self._cached_body_data.decode('utf-8'))
                
                success = add_external_index(json_body, self.external_indexes_db_path)
                
                if success:
                    self._send_response(200, {"status": "success", "message": "External index added successfully"})
                else:
                    # add_external_index already logs the error, so a generic error message is fine here
                    self._send_response(500, {"status": "error", "message": "Failed to add external index"})
            except json.JSONDecodeError:
                log(f"[Orac] Invalid JSON body for /add_ext_index", level=LOGERROR)
                self._send_response(400, {"status": "error", "message": "Invalid JSON body"})
            except Exception as e:
                log(f"[Orac] Unhandled error processing /add_ext_index: {e}", level=LOGERROR)
                self._send_response(500, {"status": "error", "message": f"Internal server error: {str(e)}"})
            return

        if path == "/del_ext_index":
            log("[Orac] Handling /del_ext_index PUT request", level=LOGINFO)
            try:
                params = self._flatten_query_params(query)
                if not params.get('index_id') or not params.get('item_type'):
                    self._send_response(400, {"status": "error", "message": "Missing 'index_id' or 'item_type' query parameter"})
                    return

                success = del_external_index(params, self.external_indexes_db_path)
                
                if success:
                    self._send_response(200, {"status": "success", "message": "External index removed successfully"})
                else:
                    # del_external_index already logs the error, so a generic error message is fine here
                    self._send_response(500, {"status": "error", "message": "Failed to remove external index"})
            except Exception as e:
                log(f"[Orac] Unhandled error processing /remove_ext_index: {e}", level=LOGERROR)
                self._send_response(500, {"status": "error", "message": f"Internal server error: {str(e)}"})
            return

        if path == "/add_internal_index":
            log("[Orac] Handling /add_internal_index PUT request", level=LOGINFO)
            try:
                if not self._cached_body_data:
                    self._send_response(400, {"status": "error", "message": "Empty request body"})
                    return
                json_body = self._cached_json_body
                if not json_body:
                    json_body = json.loads(self._cached_body_data.decode('utf-8'))
                
                success = add_internal_index(json_body, self.external_indexes_db_path)
                if success:
                    self._send_response(200, {"status": "success", "message": "Internal index added successfully"})
                else:
                    self._send_response(500, {"status": "error", "message": "Failed to add internal index"})
            except json.JSONDecodeError:
                log(f"[Orac] Invalid JSON body for /add_internal_index", level=LOGERROR)
                self._send_response(400, {"status": "error", "message": "Invalid JSON body"})
            except Exception as e:
                log(f"[Orac] Unhandled error processing /add_internal_index: {e}", level=LOGERROR)
                self._send_response(500, {"status": "error", "message": f"Internal server error: {str(e)}"})
            return

        if path == "/del_internal_index":
            log("[Orac] Handling /del_internal_index PUT request", level=LOGINFO)
            try:
                params = self._flatten_query_params(query)
                if not params.get('index_id') or not params.get('item_type'):
                    self._send_response(400, {"status": "error", "message": "Missing 'index_id' or 'item_type' query parameter"})
                    return
                success = del_internal_index(params, self.external_indexes_db_path)
                if success:
                    self._send_response(200, {"status": "success", "message": "Internal index removed successfully"})
                else:
                    self._send_response(500, {"status": "error", "message": "Failed to remove internal index"})
            except Exception as e:
                log(f"[Orac] Unhandled error processing /del_internal_index: {e}", level=LOGERROR)
                self._send_response(500, {"status": "error", "message": f"Internal server error: {str(e)}"})
            return
        
        if path == "/update_list_library_status":
            log("[Orac] Handling /update_list_library_status PUT request", level=LOGINFO)
            try:
                params = self._flatten_query_params(query)
                success = update_list_library_status(params, self.lists_db_path)
                if not success:
                    self._send_response(500, {"status": "error", "message": "Failed to update list library status"})
                    return
                self._send_response(200, {"status": "success", "message": "List library status updated"})
            except Exception as e:
                log(f"[Orac] Unhandled error processing /update_list_library_status: {e}", level=LOGERROR)
                self._send_response(500, {"status": "error", "message": f"Internal server error: {str(e)}"})
            return
        
        if path == "/unlike_trakt_list":
            log("[Orac] Handling /unlike_trakt_list PUT request", level=LOGINFO)
            try:
                params = self._flatten_query_params(query)
                list_name = params.get("list_name")
                # Ensure we have the user
                trakt_user = params.get("user") or await self._get_trakt_user()
                slug = params.get("slug")
                if not list_name or not trakt_user or not slug:
                    self._send_response(400, {"status": "error", "message": "Missing 'list_name', 'slug' parameter or Trakt user"})
                    return
                # Step 3: Queue the update to Trakt
                with sqlite3.connect(self.trakt_update_queue_path) as conn:
                    cursor = conn.cursor()
                    queue_payload = {
                        "list_name": list_name,
                        "item_type": 'list',
                        "tmdb_id": None,
                        "user": trakt_user,
                        "slug": slug
                    }
                    cursor.execute("""
                        INSERT INTO trakt_update_queue (trakt_id, update_type, payload, status, media_type)
                        VALUES (?, ?, ?, 'pending', ?)
                    """, (trakt_user, 'unlike_trakt_list', json.dumps(queue_payload), 'list'))
                    conn.commit()

                # Step 4: Local cleanup
                # Resolve list_id from DB using slug
                list_id = None
                with sqlite3.connect(self.lists_db_path) as conn:
                    cursor = conn.cursor()
                    cursor.execute("SELECT list_id FROM lists WHERE slug = ?", (slug,))
                    row = cursor.fetchone()
                    if row:
                        list_id = row[0]
                
                if not list_id:
                     # Fallback to legacy
                     list_id = f"{trakt_user}:{slug}"

                delete_list_locally(list_id, self.lists_db_path)

                self._send_response(200, {"status": "success", "message": f"Successfully unliked list '{list_name}' and removed it locally"})
            except Exception as e:
                log(f"[Orac] Unhandled error processing /unlike_list: {e}", level=LOGERROR)
                self._send_response(500, {"status": "error", "message": f"Internal server error: {str(e)}"})
            return

        if path == "/add_tag":
            log("[Orac] Handling /add_tag PUT request", level=LOGINFO)
            try:
                # Parse JSON body to get tag name
                if not self._cached_body_data:
                    self._send_response(400, {"success": False, "error": "Empty request body"})

                    return
                json_body = self._cached_json_body
                if not json_body:
                    json_body = json.loads(self._cached_body_data.decode('utf-8'))
                
                # Get parameters from query string
                params = self._flatten_query_params(query)
                media_type = params.get('media_type')
                tmdb_id_str = params.get('tmdb_id')
                tag_name = json_body.get('tag')
                
                if not media_type or not tmdb_id_str or not tag_name:
                    self._send_response(400, {"success": False, "error": "Missing media_type, tmdb_id, or tag"})
                    return
                
                try:
                    tmdb_id = int(tmdb_id_str)
                except ValueError:
                    self._send_response(400, {"success": False, "error": "Invalid tmdb_id"})
                    return
                
                # Add tag to item
                success = add_tag_to_item(
                    self.tags_db_path, media_type, tmdb_id, tag_name,
                    movies_static_db_path=self.movies_static_db_path,
                    tvshows_static_db_path=self.tvshows_static_db_path
                )
                
                if not success:
                    log(f"[Orac] Failed to add tag, attempting to fetch item {media_type}/{tmdb_id} first...", level=LOGINFO)
                    # Try to fetch item info to populate DB
                    fetch_status = 0
                    if media_type == 'movie':
                        fetch_status, _, _ = handle_movie_request(tmdb_id, self.movies_dynamic_db_path, self.movies_static_db_path, self.tmdb_handler)
                    elif media_type in ('show', 'tvshow'):
                         fetch_status, _, _ = handle_show_request(tmdb_id, "", self.tvshows_static_db_path, self.tvshows_dynamic_db_path, self.tmdb_handler)
                    
                    if fetch_status == 200:
                         # Retry adding tag
                         success = add_tag_to_item(
                            self.tags_db_path, media_type, tmdb_id, tag_name,
                            movies_static_db_path=self.movies_static_db_path,
                            tvshows_static_db_path=self.tvshows_static_db_path
                        )

                if success:
                    self._send_response(200, {"success": True, "message": f"Tag '{tag_name}' added to {media_type}/{tmdb_id}"})
                else:
                    self._send_response(500, {"success": False, "error": "Failed to add tag"})
            except json.JSONDecodeError:
                log("[Orac] Invalid JSON body for /add_tag", level=LOGERROR)
                self._send_response(400, {"success": False, "error": "Invalid JSON body"})
            except Exception as e:
                log(f"[Orac] Error processing /add_tag: {e}", level=LOGERROR)
                self._send_response(500, {"success": False, "error": f"Internal server error: {str(e)}"})
            return

        if path == "/remove_tag":
            log("[Orac] Handling /remove_tag PUT request", level=LOGINFO)
            try:
                # Get parameters from query string
                params = self._flatten_query_params(query)
                media_type = params.get('media_type')
                tmdb_id_str = params.get('tmdb_id')
                tag_name = params.get('tag')
                
                if not media_type or not tmdb_id_str or not tag_name:
                    self._send_response(400, {"success": False, "error": "Missing media_type, tmdb_id, or tag"})
                    return
                
                try:
                    tmdb_id = int(tmdb_id_str)
                except ValueError:
                    self._send_response(400, {"success": False, "error": "Invalid tmdb_id"})
                    return
                
                # Remove tag from item
                success = remove_tag_from_item(self.tags_db_path, media_type, tmdb_id, tag_name)
                
                if success:
                    self._send_response(200, {"success": True, "message": f"Tag '{tag_name}' removed from {media_type}/{tmdb_id}"})
                else:
                    self._send_response(500, {"success": False, "error": "Failed to remove tag"})
            except Exception as e:
                log(f"[Orac] Error processing /remove_tag: {e}", level=LOGERROR)
                self._send_response(500, {"success": False, "error": f"Internal server error: {str(e)}"})
            return

        # Fallback for unhandled PUT requests
        self.send_response(404)
        self.send_header("Content-type", "text/plain")
        self.end_headers()
        self.wfile.write(b"Not Found")


def _vacuum_database(db_path, db_manager=None):
    """Vacuums the specified SQLite database to reclaim space."""
    if not db_path:
        return
    try:
        log(f"[Orac] Attempting to VACUUM database: {db_path}", level=LOGINFO)
        if db_manager:
             with db_manager.connection(db_path) as conn:
                conn.execute("VACUUM")
        else:
            with sqlite3.connect(db_path) as conn:
                conn.execute("VACUUM")
        log(f"[Orac] Successfully VACUUMed database: {db_path}", level=LOGINFO)
    except sqlite3.Error as e:
        log(f"[Orac] Error vacuuming database {db_path}: {e}", level=LOGERROR)

def _schedule_vacuum(db_path, db_manager=None, interval=86400):  # Default interval is 24 hours (86400 seconds)
    """Schedules a VACUUM operation for the specified database."""
    def vacuum_timer():
        _vacuum_database(db_path, db_manager)
        _schedule_vacuum(db_path, db_manager, interval)  # Reschedule the vacuum

    if db_path:
        timer = threading.Timer(interval, vacuum_timer)
        timer.daemon = True  # Allow the main thread to exit
        timer.start()

def start_http_server(trakt_handler=None, tmdb_handler=None, port=5555, movies_static_db_path=None, movies_dynamic_db_path=None, lists_db_path=None, tvshows_static_db_path=None, 
                        tvshows_dynamic_db_path=None, trakt_update_queue_path=None, config_db_path=None, ext_indexes_db_path=None, tags_db_path=None, scrapers_dir=None, config_db_conn=None, db_manager=None):
    server_address = ('', port)
    from resources.lib.sync_trakt_with_db import trakt_list_sync_task

    log(f"[Orac] Starting HTTP server on port {port}...", level=LOGINFO)

    # Vacuum databases on startup to reclaim space
    _vacuum_database(movies_static_db_path, db_manager)
    _vacuum_database(tvshows_static_db_path, db_manager)
    _vacuum_database(lists_db_path, db_manager)

    # Schedule regular vacuuming (e.g., every 24 hours)
    _schedule_vacuum(tvshows_static_db_path, db_manager)


    if scrapers_dir:
        scraper_manager = ScraperManager(scrapers_dir)
    else:
        scraper_manager = ScraperManager()  # Use default directory
    

    # Pass values into the handler class
    SimpleHTTPRequestHandler.trakt_handler = trakt_handler
    SimpleHTTPRequestHandler.tmdb_handler = tmdb_handler
    SimpleHTTPRequestHandler.movies_static_db_path = movies_static_db_path
    SimpleHTTPRequestHandler.movies_dynamic_db_path = movies_dynamic_db_path
    SimpleHTTPRequestHandler.list_cache_path = lists_db_path
    SimpleHTTPRequestHandler.tvshows_static_db_path = tvshows_static_db_path
    SimpleHTTPRequestHandler.tvshows_dynamic_db_path = tvshows_dynamic_db_path
    SimpleHTTPRequestHandler.trakt_update_queue_path = trakt_update_queue_path
    SimpleHTTPRequestHandler.config_db_path = config_db_path
    SimpleHTTPRequestHandler.config_db_conn = config_db_conn
    SimpleHTTPRequestHandler.scraper_manager = scraper_manager
    SimpleHTTPRequestHandler.external_indexes_db_path = ext_indexes_db_path
    SimpleHTTPRequestHandler.tags_db_path = tags_db_path
    SimpleHTTPRequestHandler.db_manager = db_manager


    # Initialize Global Loop
    global_loop = asyncio.new_event_loop()
    SimpleHTTPRequestHandler.global_loop = global_loop

    def start_background_loop(loop):
        asyncio.set_event_loop(loop)
        loop.run_forever()

    # Start the loop in a separate thread
    loop_thread = threading.Thread(target=start_background_loop, args=(global_loop,), daemon=True)
    loop_thread.start()

    log(f"[Orac] Global asyncio loop started in background thread.", level=LOGINFO)

    httpd = ThreadingHTTPServer(server_address, SimpleHTTPRequestHandler)

    def server_thread():
        httpd.serve_forever()

    thread = threading.Thread(target=server_thread, daemon=True)
    thread.start()
    log(f"[Orac] HTTP server started on port {port}...", level=LOGINFO)

    # Start the async task to sync trakt lists
    async def hourly_sync_loop(trakt_auth, lists_db_path, trakt_queue_worker):
        while True:
            try:
                # Always fetch the latest username in case it was updated
                current_username = get_trakt_user(config_db_path=config_db_path)
                
                await sync_lists_and_items(
                    trakt_auth,
                    tmdb_handler,
                    movies_static_db_path,
                    movies_dynamic_db_path,
                    tvshows_static_db_path,
                    tvshows_dynamic_db_path,
                    lists_db_path,
                    trakt_update_queue_path,
                    trakt_queue_worker,
                    current_username,
                    external_indexes_db_path=ext_indexes_db_path,
                    config_db_path=config_db_path,
                    tags_db_path=tags_db_path
                )
            except Exception as e:
                log(f"[Orac] Error in hourly sync loop: {e}", level=LOGERROR)
            
            await asyncio.sleep(3600)

    async def startup_tasks():
        trakt_user = get_trakt_user(config_db_path=config_db_path)
        if not trakt_user and trakt_handler:
            trakt_user = await trakt_handler.fetch_username()
        
        if trakt_user:
            log(f"[Orac] Trakt user: {trakt_user}", level=LOGINFO)
        else:
            log("[Orac] No Trakt user found at startup.", level=LOGWARNING)
            
        # Schedule the hourly sync on the global loop
        # This must happen AFTER trakt_queue_worker and trakt_user are initialized
        asyncio.create_task(hourly_sync_loop(trakt_handler, lists_db_path, trakt_queue_worker))

    trakt_queue_worker = UpdateQueueWorker(trakt_update_queue_path, tvshows_static_db_path, trakt_handler, tmdb_handler, db_manager, config_db_path)
    trakt_queue_worker.start()  # Starts running in background
    SimpleHTTPRequestHandler.trakt_queue_worker = trakt_queue_worker
    log(f"[Orac] Update queue worker started...", level=LOGINFO)

    if trakt_handler:
        future = asyncio.run_coroutine_threadsafe(startup_tasks(), global_loop)
        # We can't await future here as this is blocking, but we can add a callback (if we were in async)
        # or just rely on the fact that exceptions in tasks are logged if retrieved.
        # Check future for immediate errors? No, it's concurrent.
        # But we can define a done callback.
        def startup_callback(f):
            try:
                f.result()
            except Exception as e:
                log(f"[Orac] Startup tasks FAILED: {e}", level=LOGERROR)
        future.add_done_callback(startup_callback)

    # Return HTTP server and worker so caller can shut them down cleanly
    return httpd, trakt_queue_worker